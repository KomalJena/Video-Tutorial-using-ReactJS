import React from 'react';
import { Link } from 'react-router-dom';
import './Styling.css';
import Navigationbar from './Navigationbar';
function Home(props) {
    //console.log(props);

    return (
        <>
            <Navigationbar />
            <div className="container cnt">
                <h1 className="text-center">WELCOME</h1>
                <div className="row mt-4">
                    <div className="col s6 m4">

                        <Link to="/html">
                            <div className="card purple accent-1  hoverable">
                                <div className="card-content">

                                    <h3 className=" text-center flow-text text-warning">HTML5 course</h3>
                                </div>
                            </div>
                        </Link>

                    </div>
                    <div className="col  s6 m4 ">

                        <Link to="/bootstrap">
                            <div className="card  blue lighten-5  hoverable">
                                <div className="card-content">

                                    <h3 className="  text-center text-warning " >BootStrap course</h3>
                                </div>
                            </div>
                        </Link>

                    </div>
                    <div className="col  s6 m4">
                        <Link to="/javascript">
                            <div className="card blue-grey lighten-3  hoverable">
                                <div className="card-content">

                                    <h3 className="  text-center text-warning">JS/ES6 course</h3>
                                </div>
                            </div>
                        </Link>
                    </div>
                    <div className="col s6 m4 ">

                        <Link to="/reactjs">
                            <div className="card  brown darken-2  hoverable">
                                <div className="card-content">

                                    <h3 className=" text-center text-warning">Reactjs course</h3>
                                </div>
                            </div>
                        </Link>

                    </div>
                    <div className="col  s6 m4 ">

                        <Link to="/nodejs">
                            <div className="card  light-green lighten-3  hoverable ">
                                <div className="card-content">
                                    <h3 className=" text-center">Nodejs course</h3>
                                </div>

                            </div>
                        </Link>

                    </div>
                    <div className="col  s6 m4 ">
                        <Link to="/expressjs">
                            <div className="card lime lighten-1  hoverable">
                                <div className="card-content">
                                    <h3 className="my-5 text-center text-dark">Expressjs course</h3>
                                </div>

                            </div>
                        </Link>
                    </div>
                </div>
            </div>
        </>
    );
}

export default Home;