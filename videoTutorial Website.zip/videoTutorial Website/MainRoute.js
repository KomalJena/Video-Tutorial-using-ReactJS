import React, { Component } from 'react';
import { BrowserRouter, Switch, Route } from "react-router-dom";
import Login from './Login';
import Logout from './Logout';
//import VideoFunction from './VideoFunction';
//import Navigationbar from './Navigationbar'
//import Register from './Register';
import Home from './Home';
import CourseStru from './CourseStru';
class MainRoute extends Component {
    render() {
        return (

            <BrowserRouter>
                <Switch>
                    <Route exact path='/' component={Home} />
                    <Route path="/Login" component={Login} />
                    <Route path="/Logout" component={Logout} />
                    <Route path="/:coursename" component={CourseStru} />
                </Switch>
            </BrowserRouter>

        );
    }
}

export default MainRoute;