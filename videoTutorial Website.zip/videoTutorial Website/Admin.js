import React, { Component } from 'react';
import { Link, Redirect } from 'react-router-dom';
import Navigationbar from './Navigationbar';
import VideoFunction from '../videoplayer/VideoFunction';
class Admin extends Component {
    constructor(props) {
        super(props);
        const token = localStorage.getItem("userlogin");
        let loggedin = false;
        if (token != null) {
            loggedin = true;
        }
        this.state = {
            loggedin
        }
    }
    render() {
        if (this.state.loggedin === false) {
            return <Redirect to="/" />
        }
        return (
            <>
                <Navigationbar />
                <VideoFunction />
            </>
        );
    }
}

export default Admin;