import React, { Component } from 'react';
import { Link, Redirect } from 'react-router-dom';
import Navigationbar from './Navigationbar';
class Logout extends Component {
    constructor(props) {
        super(props);
        localStorage.removeItem("userlogin");
        localStorage.removeItem("loginpassword");
        this.msg = this.msg.bind(this)
    }
    msg() {
        alert("logoutsuccess");
    }
    render() {

        return (
            <>
                <Navigationbar />
                <div>
                    {this.msg()}
                    <Redirect to="/" />
                </div>
            </>
        );
    }
}

export default Logout;