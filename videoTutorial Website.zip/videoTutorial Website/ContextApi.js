import React from 'react';

const ContextApi = React.createContext({
    name: 'logout',
    loggedin: false
}
);
export default ContextApi;