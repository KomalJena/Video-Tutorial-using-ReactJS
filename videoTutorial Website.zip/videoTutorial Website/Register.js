import React, { Component } from 'react';
import {Redirect} from 'react-router-dom';
import './Styling.css';

class Register extends Component {
    constructor(props)
    {
        super(props);
        const token=localStorage.getItem("token");
        let regis=true;
        if(token==null)
        {
            regis=false;
        }
        this.state={
            username:'',
            password:'',
            regis
        }
        this.onchangeHandeler=this.onchangeHandeler.bind(this);
        this.submitForm=this.submitForm.bind(this);
    }
    onchangeHandeler(e){
        this.setState({
            [e.target.name]:e.target.value
        })
    }
    submitForm(e)
    {
        e.preventDefault();
        const{username,password}=this.state;
        localStorage.setItem("token",username);
        localStorage.setItem("password",password);
        this.setState({regis:true})
      

    }
    render() {
        if(this.state.regis)
        {
           // alert('redirect to login')
            return <Redirect to="/Login" />
        }
        return (
            <div className="form">
             <form className="form-control col-6 m-4" onSubmit={this.submitForm}>
                <h1>Registration</h1> 
                <input type="text" className="form-control" name="username" value={this.state.username} onChange={this.onchangeHandeler} placeholder="Enter Username" />
                <input type="password" className="form-control" name="password" value={this.state.password} onChange={this.onchangeHandeler} placeholder="Enter Password"/>
                <input type="submit" className="btn btn-primary" />
                </form>
          
            </div>
        );
    }
}

export default Register;