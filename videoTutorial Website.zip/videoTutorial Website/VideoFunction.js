import React, { Component } from 'react'
import {BrowserRouter,Route,Switch,Redirect} from 'react-router-dom';
import Home from '../videoplayer/Home';
import CourseStru from '../videoplayer/CourseStru';
import Navigationbar from './Navigationbar';
export default class VideoFunction extends Component {
    constructor(props)
    {
        super(props);
        const token=localStorage.getItem("userlogin");
        let loggedin=false;
        if(token!=null)
        {
            loggedin=true;
        }
        this.state={
            loggedin
        }
    }
    render() {
        if(this.state.loggedin===false)
        {
            return <Redirect to="/" />
        }
    return (
        <>
         <Navigationbar />
        <div className="container">
            <Home />
            <BrowserRouter>
            <Switch>
            <Route path="/:coursename" component={CourseStru}/>
            </Switch>
           
           
            </BrowserRouter>
        </div>
        </>
    );
}
    
}
