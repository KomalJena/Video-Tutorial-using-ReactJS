import React, { Component } from 'react'
import './Styling.css';
import MainRoute from './MainRoute';
import { Redirect } from 'react-router-dom';
//import ContextApi from './ContextApi';
export default class Navigationbar extends Component {
    constructor() {
        super()
        this.state = {
            clicking: false,
            logout: false
        }
    }
    render() {

        return (
            <>
                <nav class="navbar navbar-inverse nv navbar-fixed">
                    <div class="container-fluid">
                        <div class="navbar-header">
                            <button type="button" class="navbar-toggle bg-danger" data-toggle="collapse" data-target="#myNavbar">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                            <a class="navbar-brand amber-text" href="/"></a>
                        </div>
                        <div class="collapse navbar-collapse" id="myNavbar">
                            <ul class="nav navbar-nav navbar-right ">

                                {
                                    localStorage.getItem("userlogin") ?
                                        <li className="list lime-text" onClick={() => {
                                            this.setState({ logout: !this.state.logout })
                                        }}>{localStorage.getItem('userlogin')}<span class="glyphicon glyphicon-user " style={{ marginLeft: '1px', backgroundColor: 'blue' }} ></span></li> : <li className="list lime-text mb-sm-4" onClick={() => {
                                            this.setState({ clicking: !this.state.clicking })
                                        }}><span class="glyphicon glyphicon-user " ></span>Signup/Login</li>
                                }

                            </ul>
                        </div>
                    </div>
                </nav>
                {
                    this.state.clicking ? <Redirect to="/Login" /> : null

                }
                {
                    this.state.logout ? <Redirect to="/Logout" /> : null

                }


            </>

        )
    }
}
